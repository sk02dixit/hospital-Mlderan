<?php
session_start();
$emailaddress=$_POST["emailaddress"];
$password=$_POST["password"];

$con=mysqli_connect("localhost","root","","managementdb");
$query="select password from patientdb where emailaddress='$emailaddress'";
$res=mysqli_query($con,$query);

if (mysqli_num_rows($res)>0)
{
    if($row=mysqli_fetch_assoc($res))
    {
        $respassword=$row["password"];
        if($password==$respassword)
        {
            $_SESSION["valid"]=$emailaddress;    
            echo "<script>alert('Login Successfully');window.location.href='appointment.php';</script>";
            
        }
        else
        {
            echo "<script>alert('Invalid user😡😠😠');   
            window.location.href='login.php';</script>";   //email is correct but password is not correct then msg show Invalid user
        }
    }

}

?>