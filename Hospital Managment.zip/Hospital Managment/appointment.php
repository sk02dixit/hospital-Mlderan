<!DOCTYPE html>
<html lang="en">
<head>
    <title>Medlink</title>
    <link href="css/bootstrap.css" rel="stylesheet"/>
      
       <script src="js/bootstrap.bundle.js"></script>
       <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
       <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
	
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/solid.min.css" integrity="sha512-uj2QCZdpo8PSbRGL/g5mXek6HM/APd7k/B5Hx/rkVFPNOxAQMXD+t+bG4Zv8OAdUpydZTU3UHmyjjiHv2Ww0PA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="js/bootstrap.bundle.js"></script>
  
    <style>
        .navbar li:hover
        {
            height:40px;
            background-color:#0d6efd;
            border-radius:10px;
        }
        
        .navbar li a:hover
        {
            color:pink;
        }
        .img2
        {
            transition: ease 2s;
        }
        .img2:hover
        {
            transform: scale(.9);
        }
        
    
    </style>
</head>
<body>
    <!---------------Header-------------->
    <div class="container-fluid">
        <div class="row" style="background-color:#f6f9fd;min-height:40px;">
            <div class="col-sm-1"></div>
            <div class="col-sm-3">
            <i class="fa-solid fa-envelope text-primary mt-2"></i><span class="mx-2">@infomedilinkhospital.com</span>
            </div>
            <div class="col-sm-2">
            <i class="fa-solid fa-mobile text-primary mt-2"></i><span class="mx-2">+1 5589 55488 55</span>
            </div>
            <div class="col-sm-3">
                <i class="fa-solid fa-location-dot text-primary mt-2"></i><span class="mx-2">Medilink (Ltd) , Newyork City</span>
            </div>
            <div class="col-sm-1"></div>
            
            <div class="col-sm-2">
                <div class="row">
                    <div class="col-sm-12 mt-2 text-primary">
                        <i class="fa-brands fa-instagram mx-1"></i>
                        <i class="fa-brands fa-facebook mx-1"></i>
                        <i class="fa-brands fa-twitter mx-1"></i>
                        <i class="fa-brands fa-youtube"></i>
                    </div>
                </div>
            </div>
           
        </div>
    </div>
    <!-----------Navbar----------------->
    <div class="container-fluid">
        <div class="row" style="background-color:#e4eaf0;">
            <div class="col-sm-1"></div>
            <div class="col-sm-1">
                <strong style="font-size:40px;color:#2c4964;font-family:gabrilla;">Medilink</strong>
            </div>
            <div class="col-sm-1"></div>
            <div class="col-sm-9">
            <nav class="navbar navbar-expand-lg bg-body-tertiary">
                <div class="container-fluid">
                    
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <b><ul class="navbar-nav">
                           <li class="nav-item">
                                <a class="nav-link mx-1"  href="medlab.php">Home</a>
                           </li>
                           <li class="nav-item">
                                <a class="nav-link mx-1" href="about.php">About Us</a>
                           </li>
                           <li class="nav-item">
                                <a class="nav-link mx-1" href="login.php">User Login</a>
                           </li>
                           <li class="nav-item">
                                <a class="nav-link mx-1" href="facilities.phpo">Facilities</a>
                           </li>
                           <li class="nav-item">
                                <a class="nav-link mx-1" href="contact.php">Contact Us</a>
                           </li>
                           <li class="nav-item">
                                <a class="nav-link mx-1" href="doctors.php">Doctors</a>
                           </li>
                           <li class="nav-item">
                                <a class="nav-link mx-1" href="registration.php">Registration</a>
                           </li>
                           <a href="adminlogin.php"><input type="submit" value="Admin Login" name="submit" class="btn btn-primary mx-5" style="width:150px;"></a>
                        </ul></b>
                    </div>
                </div>
            </nav>
            </div>
            
        </div>
    </div>
    <!---------------Patient Information ---------->
    <div class="container-fluid">
        <div class="row" style="background-color:#f1f7fd;background-image:url('img/img.jpg');background-size:cover;min-height:50px;">
            <div class="col-sm-1"></div>
            <div class="col-sm-10 mt-5" style="box-shadow:3px 3px 50px 10px ;min-height:600px;">
                <form action="appointmentcode.php" method="post">
                    <div class="row mt-5">
                        <div class="col-sm-12">
                            <h1 class="text-center text-secondary"  style="font-size:60px;font-family:gabrilla;border-radius:10px;"><span class="text-primary">Make an Appointment</span></h1>
                        </div>
                        <div class="row mt-2">
                           <div class="col-sm-5"></div>
                           <div class="col-sm-2"><hr style="border:2px solid #0d6efd;margin-top:-5px;margin-left:30px;border-radius:10%;"/></div>
                           <div class="col-sm-5"></div>
                        </div>
                    </div>
                
                    <div class="row mt-4">
                    <div class="col-sm-6 ">
                        <input type="text" name="name" id="name" required="true" class="form-control" placeholder="Enter Patient Name"><br/>
                        <input type="number" name="contactno" id="contactno" required="true" class="form-control" placeholder="Enter patient Mobile Number"><br/>
                        <select name="department" id="department" class="form-control">
                             <option value="">Select Department</option>
                             <option value="Department 1">Cardiology</option>
                             <option value="Department 2">Neurology</option>
                             <option value="Department 3">Hepatology</option>
                             <option value="Department 4">Pediatrics</option>
                        </select>
                    </div>
                    <div class="col-sm-6">
                        <input type="email" name="emailaddress" id="emailaddress" class="form-control" required="true" placeholder="Enter Patient Email Address"><br/>
                        <input type="text" name="appointdate" id="appointdate" class="form-control" required="true" placeholder="Appointment Date"><br/>
                        <select name="doctor" id="doctor" class="form-control">
                             <option value="">Select Doctor</option>
                             <option value="Doctor 1"> Dr Satish Kumar</option>
                             <option value="Doctor 2">Dr Kiran Gupta</option>
                             <option value="Doctor 3">Dr Asok Agrawal</option>
                             <option value="Doctor 4">Dr Ashish Kumar</option>
                        </select>
                    </div>
                    </div><br/>
                    <textarea name="address" id="address" class="form-control" placeholder="Message (Option)"rows="5"></textarea>
                    <div class="row">
                        <div class="col-sm-5"></div>
                        <div class="col-sm-2 mt-4">
                            <input type="submit" value="Make An Appointment" name="appointment" class="btn btn-primary">
                        </div>
                        <div class="col-sm-5"></div>
                    </div>
                </form>
            </div>
            <div class="col-sm-1"></div>
        </div>
    </div>

     <!--------------footer---------------------->
    <div class="container-fluid">
        <div class="row  bg-dark" style="min-height:350px;">
                <div class="col-sm-1"></div>
                    <div class="col-sm-10">
                        <div class="row">
                            <div class="col-sm-3">
                                <h1 class="text-info mt-4"><span class="text-info">||</span> &nbsp;Medilink</h1><br/>
                                <p class="text-white" style="text-align:justify;">We started our journey since 2002 and thus state with pride and gratitude that we have completed two decades of journey successfully. Our team at Medilink Multispecialty Hospitals consists of specialists & Super specialists from all Branches.</p>
                            </div>
                            <div class="col-sm-3 mt-4">
                                <h5 class="text-info mx-4">USEFUL LINKS</h5><hr class="mx-4" style="border:2px solid pink;"/>
                                <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;"> >  Home</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                                <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;"> >  About Us</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                                <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;"> >  Portpolio</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                                <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;"> >  Career</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                                <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;"> >  Contact</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                            </div>
                            <div class="col-sm-3 mt-4">
                                <h5 class="text-info mx-4">Contact Us</h5><hr class="mx-4 " style="border:2px solid pink;"/>
                                <p class="text-white mx-4">Medilink<br/>
                                    Near New Spainees Hotel<br/>
                                    NewYork City , 226006<br/>
                                    U.S.A<br/>
                                    Call us @ + 91 7080102011<br/>
                                    Email @infomedilink.com<br/>
                                </p>
                                <div class="row">
                                    <div class="col-sm-1"></div>
                                    <div class="col-sm-2 rad" style="border-radius:50%;background-color:grey;height:50px;width:50px;"  >
                                       <i class="fa-brands fa-instagram" style="color:red;padding:1px;margin-top:12px;font-size:25px;"></i>
                                    </div>
                                    <div class="col-sm-2 rad" style="border-radius:50%;background-color:grey;height:50px;width:50px;" >
                                        <i class="fa-brands fa-facebook" style="color:blue;padding:1px;margin-top:12px;font-size:25px;"></i>
                                    </div>
                                   <div class="col-sm-2 rad" style="border-radius:50%;background-color:grey;height:50px;width:50px;" >
                                        <i class="fa-brands fa-youtube" style="color:red;margin-top:14px;font-size:23px;"></i>
                                    </div>
                                    <div class="col-sm-2 rad" style="border-radius:50%;background-color:grey;height:50px;width:50px;" >
                                        <i class="fa-brands fa-twitter" style="color:skyblue;padding:1px;margin-top:12px;font-size:25px;"></i>
                                    </div>
                                    <div class="col-sm-2 rad" style="border-radius:50%;background-color:grey;height:50px;width:50px;" >
                                        <i class="fa-brands fa-linkedin" style="color:blue;padding:1px;margin-top:12px;font-size:25px;"></i>
                                    </div>
                                    <div class="col-sm-1"></div>
                                </div>
                            </div>
                            <div class="col-sm-3 mt-4">
                                <h5 class=" mx-4 text-info" style="color:white;">DOWNLOADS</h5><hr class="mx-4" style="border:2px solid pink;"/>
                                <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;"> Hospital PROFILE</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                                <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;font-size:16px;"> Hospital Management</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                                <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;font-size:16px;"> Hospital Facility</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                                <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;font-size:16px;"> Hospital Services</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                        
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-1"></div>
            </div>
            <div class="row bg-dark" style="height:110px;">
            <div class="col-sm-12">
                <p class="text-center mt-4 text-white">© Copyright <strong>Medilink  Hospital.</strong> All Rights Reserved <br/>
                                       Designed by <b style="color:lime;">Mr Shivam Kumar Dixit</b><p>
            </div>
            </div>
    </div>
</body>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js" rel="stylesheet"></script>
<script src="js/app.js"></script>
</html>
    
        
</body>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js" rel="stylesheet"></script>
<script src="js/app.js"></script>
</html>