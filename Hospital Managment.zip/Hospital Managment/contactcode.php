<?php
if(isset($_POST["contact"]))
{
$name=$_POST["name"];
$emailaddress=$_POST["emailaddress"];
$contactno=$_POST["contactno"];
$address=$_POST["address"];
$con=mysqli_connect("localhost","root","","managementdb");
$query="insert into contact(name,emailaddress,contactno,address) values ('$name','$emailaddress','$contactno','$address')";
mysqli_query($con,$query);
echo "<script>alert('Registration is Done');window.location.href='medlab.php';</script>";
}
else
{
    
    echo "<script>alert('Registration is not Done');<script>";
}
?>