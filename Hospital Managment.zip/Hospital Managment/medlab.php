<!DOCTYPE html>
<html lang="en">
<head>
    <title>Medlink</title>
    <link href="css/bootstrap.css" rel="stylesheet"/>
      
       <script src="js/bootstrap.bundle.js"></script>
       <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
       <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
	
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/solid.min.css" integrity="sha512-uj2QCZdpo8PSbRGL/g5mXek6HM/APd7k/B5Hx/rkVFPNOxAQMXD+t+bG4Zv8OAdUpydZTU3UHmyjjiHv2Ww0PA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="js/bootstrap.bundle.js"></script>
  
    <style>
        .navbar li:hover
        {
            height:40px;
            background-color:#0d6efd;
            border-radius:10px;
        }
        .navbar li a:hover
        {
            color:pink;
        }
        .card-body:hover
        {
            background-color:#0d6efd;
            color:white;
        }
        .a1:hover
        {
            color:#0d6efd;
        }
        .a2:hover
        {
            color:#0d6efd;
        }
        .a3:hover
        {
            color:#0d6efd;
        }
        .a4:hover
        {
            color:#0d6efd;
        }
        .a5:hover
        {
            color:#0d6efd;
        }
        .img2
        {
            transition: ease 2s;
        }
        .img2:hover
        {
            transform: scale(.9);
        }
    </style>
</head>
<body>
    <!---------------Header-------------->
    <div class="container-fluid">
        <div class="row" style="background-color:#f6f9fd;min-height:40px;">
            <div class="col-sm-1"></div>
            <div class="col-sm-3">
            <i class="fa-solid fa-envelope text-primary mt-2"></i><span class="mx-2">@infomedilinkhospital.com</span>
            </div>
            <div class="col-sm-2">
            <i class="fa-solid fa-mobile text-primary mt-2"></i><span class="mx-2">+1 5589 55488 55</span>
            </div>
            <div class="col-sm-3">
                <i class="fa-solid fa-location-dot text-primary mt-2"></i><span class="mx-2">Medilink (Ltd) , Newyork City</span>
            </div>
            <div class="col-sm-1"></div>
            
            <div class="col-sm-2">
                <div class="row">
                    <div class="col-sm-12 mt-2 text-primary">
                        <i class="fa-brands fa-instagram mx-1"></i>
                        <i class="fa-brands fa-facebook mx-1"></i>
                        <i class="fa-brands fa-twitter mx-1"></i>
                        <i class="fa-brands fa-youtube"></i>
                    </div>
                </div>
            </div>
           
        </div>
    </div>
    <!-----------Navbar----------------->
    <div class="container-fluid">
        <div class="row" style="background-color:#e4eaf0;">
            <div class="col-sm-1"></div>
            <div class="col-sm-1">
                <strong style="font-size:40px;color:#2c4964;font-family:gabrilla;">Medilink</strong>
            </div>
            <div class="col-sm-1"></div>
            <div class="col-sm-9">
            <nav class="navbar navbar-expand-lg bg-body-tertiary">
                <div class="container-fluid">
                    
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <b><ul class="navbar-nav">
                           <li class="nav-item">
                                <a class="nav-link mx-1"  href="medlab.php">Home</a>
                           </li>
                           <li class="nav-item">
                                <a class="nav-link mx-1" href="about.php">About Us</a>
                           </li>
                           <li class="nav-item">
                                <a class="nav-link mx-1" href="login.php">User Login</a>
                           </li>
                           <li class="nav-item">
                                <a class="nav-link mx-1" href="facilities.php">Facilities</a>
                           </li>
                           <li class="nav-item">
                                <a class="nav-link mx-1" href="contact.php">Contact Us</a>
                           </li>
                           <li class="nav-item">
                                <a class="nav-link mx-1" href="doctors.php">Doctors</a>
                           </li>
                           <li class="nav-item">
                                <a class="nav-link mx-1" href="Registration.php">Registration</a>
                           </li>
                           <a href="adminlogin.php"><input type="submit" value="Admin Login" name="submit" class="btn btn-primary mx-5" style="width:150px;"></a>
        
                        </ul></b>
                    </div>
                </div>
            </nav>
            </div>
            
        </div>
    </div>
   
    <!---------------Slider--------------------->
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12 p-0">
            <div id="carouselExampleCaptions" class="carousel slide">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="img/hero-bg.jpg" class="d-block w-100" height="600px" alt="...">
      <div class="carousel-caption d-none d-md-block">
      <h1 class="text-primary"style="margin-right:30%;margin-top:-30%;" data-aos="fade-right" data-aos-duration="2000">We Take Care of Healthy Health</h1>
        <h5 class="text-secondary"style="margin-right:30%;" data-aos="fade-left" data-aos-duration="2000">Our team at Medilink Multispecialty Hospitals</h5>
      </div>
    </div>
    <div class="carousel-item">
      <img src="img/a2.jpg" class="d-block w-100" height="600px" alt="...">
      <div class="carousel-caption d-none d-md-block">
      <h1 class="text-primary"style="margin-right:30%;margin-top:-30%;" data-aos="fade-right" data-aos-duration="2000">We Take Care of Healthy Health</h1>
        <h5 class="text-secondary"style="margin-right:30%;" data-aos="fade-left" data-aos-duration="2000">Our team at Medilink Multispecialty Hospitals</h5>
      </div>
    </div>
    <div class="carousel-item">
      <img src="img/a1.jpg" class="d-block w-100"height="600px" alt="...">
      <div class="carousel-caption d-none d-md-block">
      <h1 class="text-primary"style="margin-right:30%;margin-top:-30%;" data-aos="fade-right" data-aos-duration="2000">We Take Care of Healthy Health</h1>
        <h5 class="text-secondary"style="margin-right:30%;" data-aos="fade-left" data-aos-duration="2000">Our team at Medilink Multispecialty Hospitals</h5>
      </div>
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
            </div>
        </div>
    </div>
    <!-------------------Animation----------->
    <div class="container-fluid">
    <div class="row bg-white">
                <div class="col-sm-6">
                    <img src="img/a9.gif" width="100%" height="600px;"/>
                </div>
                <div class="col-sm-6 mt-5">
                    <h1 class="mx-5 mt-5" style="font-size:45px;"><span class="text-info">Medilink </span>Hospitals</h1>
                    <h4  class="mx-5">Multispeciality Hospitals</h4>
                    <p class="mx-5" style="text-align:justify;">We started our journey since 2002 and thus state with pride and gratitude that we have completed two decades of journey successfully. Our team at Medilink Multispecialty Hospitals consists of specialists & Super specialists from all Branches. We are serving from two branches in Ahmedabad- Satellite & Sabarmati. Both the units are state-of-art multi-speciality hospital set ups situated at strategic locations, and have all required departments/facilities. Apart from this, we also have 24 *7 Radiology, pathology & In-house Pharmacy services.</p><br/>
                    <p class="mx-5"style="text-align:justify;">One of our major speciality, is being run under the banner of Medilink Diabetes Clinics, and headed by the Diabetic & Metabolic Physician and Diabetologist Dr. Manish Agarwal. We, at Medilink Diabetes Clinic are dedicated to delivering world-class care and management of diabetes and related metabolic disorders.</p>
                </div>
                
            </div>
    </div>
    <!---------------------Services -------------------->
    <div class="container-fluid">
        <div class="row mt-5">
            <div class="col-sm-12">
                <h1 class="text-center text-primary" style="font-family:gabrilla">Services</h1>
            </div>
            <div class="row">
               <div class="col-sm-5"></div>
               <div class="col-sm-2"><hr style="border:2px solid #0d6efd;margin-top:-5px;margin-left:30px;border-radius:10%;"/></div>
               <div class="col-sm-5"></div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-2"></div>
            <div class="col-sm-8">
                <p style="color:grey;" >Hospitals have long existed in most countries. Developing countries, which contain a large proportion of the world do not <span class="mx-5 ms-5">have enough hospitals, equipment, and trained staff to handle the volume of persons who need care.</span></p>
            </div>
            <div class="col-sm-2"></div>
        </div>
    </div>
    <!------------------images------------------>
    <div class="container">
        <div class="row mt-3">
        <div class="col-sm-4" data-aos="fade-up" data-aos-duration="2000">
                <div class="card" style="width:100%;">
                   <div class="card-body">
                       <div class="row">
                        <div class="col-sm-4"></div>
                        <div class="col-sm-4 mt-5">
                        <i class="fa-solid fa-heart-pulse" style="font-size:60px;"></i>
                        </div>
                        <div class="col-sm-4"></div>
                        <h3 class="text-center mt-2">About your heart-pulse</h3>
                        <p class="text-center">knowledge about your heart rate can help you monitor your fitness level </p>
                       </div>
                      
                    </div>
                </div>
           </div>
           <div class="col-sm-4" data-aos="fade-up" data-aos-duration="2000">
           <div class="card" style="width:100%;">
                   <div class="card-body">
                   <div class="row">
                        <div class="col-sm-4"></div>
                        <div class="col-sm-4 mt-5" >
                        <i class="fa-solid fa-hospital-user" style="font-size:60px;"></i>
                        </div>
                        <div class="col-sm-4"></div>
                       </div>
                       <h3 class="text-center mt-2">A Contact is essential</h3>
                        <p class="text-center">A Contact Us page is essential to building a brand’s website it allows visitors </p>
                    </div>
                </div>
           </div>
           <div class="col-sm-4" data-aos="fade-up" data-aos-duration="2000">
           <div class="card" style="width:100%;">
                   <div class="card-body">
                   <div class="row">
                        <div class="col-sm-4"></div>
                        <div class="col-sm-4 mt-5">
                        <i class="fa-solid fa-wheelchair" style="font-size:60px;"></i>
                        </div>
                        <div class="col-sm-4"></div>
                       </div>
                       <h3 class="text-center mt-2">Power Wheel Chair</h3>
                       <p class="text-center">This wheelchair has fully enabled you to travel and see so many amezing places.</p>
                    </div>
                    
                    </div>
                </div>
           </div>
        </div>
    </div>
    <!-------------------------Department----------------->
    <div class="container">
        <div class="row mt-5">
        <div class="col-sm-12">
                <h1 class="text-center text-primary" style="font-family:gabrilla;" >Department</h1>
            </div>
            <div class="row">
               <div class="col-sm-5"></div>
               <div class="col-sm-2"><hr style="border:2px solid #0d6efd;margin-top:-5px;margin-left:30px;border-radius:10%;"/></div>
               <div class="col-sm-5"></div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <p class="text-center text-secondary" >Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea. Quia fugiat sit in iste officiis commodi quidem hic quas.</p>
            </div>
        </div>
       </div>
    </div>
    <!----------------Content----------------->
    <div class="container">
        <div class="row mt-4">
        <div class="col-sm-3 special" style="border-right:2px solid grey;">
                <b><p class="a1 text-primary mx-4">Cardiology</p>
                <p class="a2 mx-4">Neurology</p>
                <p class="a3 mx-4">Hepatology</p>
                <p class="a4 mx-4">Pediatrics</p>
                <p class="a5 mx-4">Eye Care</p></b>
                
            </div>
            <div class="col-sm-7">
                <h3 class="mx-4">Cardiology</h3>
                <p class="mx-4 text-secondary">Qui laudantium consequatur laborum sit qui ad sapiente dila parde sonata raqer a videna mareta paulona marka</p>
                <p class="mx-4 text-secondary">Et nobis maiores eius. Voluptatibus ut enim blanditiis atque harum sint. Laborum eos ipsum ipsa odit magni. Incidunt hic ut molestiae aut qui. Est repellat minima eveniet eius et quis magni nihil. Consequatur dolorem quaerat quos qui similique accusamus nostrum rem vero</p>
            </div>
            <div class="col-sm-2" data-aos="fade-down" data-aos-duration="2000">
                <img src="img/departments-1.jpg" width="100%">
            </div>
        </div>
    </div>
    <!---------------------Facility------------------>
    <div class="container-fluid">
        <div class="row bg-white mt-1" style="background-image:url('images/footer-bg.png');height:200px;background-repeat:no-repeat;">
                <div class="col-sm-4"></div>
                <div class="col-sm-5">
                    <h2 class="mx-5 ms-5 mt-5" ><span class="text-primary" style="color#0082cf;:height:50px;border-bottom:4px solid ;">CASHLESS</span> TREATMENT</h2>
                    <p >we accept most leading health insurance policies. Avail the benefits of</p>
                </div>
                <div class="col-sm-3"></div>
        </div>
        <div class="row">
                <div class="col-sm-1"></div>
                <div class="col-sm-10">
                    <div class="row">
                        <div class="col-sm-3" data-aos="fade-down" data-aos-duration="2000">
                        <div class="card" style="width:100%;">
                           <img src="img/4.png" class="card-img-top" >
                               
                            </div>
                        </div>
                        <div class="col-sm-3" data-aos="fade-down" data-aos-duration="2000">
                        <div class="card" style="width:100%;">
                           <img src="img/6.png" class="card-img-top" alt="...">
                               
                            </div>
                        </div>
                        <div class="col-sm-3" data-aos="fade-down" data-aos-duration="2000">
                        <div class="card" style="width:100%;">
                           <img src="img/14.png" class="card-img-top" alt="...">
                               
                            </div>
                        </div>
                        <div class="col-sm-3" data-aos="fade-down" data-aos-duration="2000">
                        <div class="card" style="width:100%;">
                           <img src="img/19.png" class="card-img-top" alt="...">
                               
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-1"></div>
            </div>
            
            <div class="row mt-5">
                <div class="col-sm-1"></div>
                <div class="col-sm-10">
                    <div class="row">
                        <div class="col-sm-3" data-aos="fade-up" data-aos-duration="2000">
                        <div class="card" style="width:100%;">
                           <img src="img/7.png" class="card-img-top" alt="...">
                               
                            </div>
                        </div>
                        <div class="col-sm-3" data-aos="fade-up" data-aos-duration="2000">
                        <div class="card" style="width:100%;">
                           <img src="img/8.png" class="card-img-top" alt="...">
                               
                            </div>
                        </div>
                        <div class="col-sm-3" data-aos="fade-up" data-aos-duration="2000">
                        <div class="card" style="width:100%;">
                           <img src="img/15.png" class="card-img-top" alt="...">
                               
                            </div>
                        </div>
                        <div class="col-sm-3" data-aos="fade-up" data-aos-duration="2000">
                        <div class="card" style="width:100%;">
                           <img src="img/9.png" class="card-img-top" alt="...">
                               
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-1"></div>
            </div>
    </div>
    <!------------------Gallary---------->
    <div class="container">
        <div class="row mt-5">
        <div class="col-sm-12">
                <h1 class="text-center text-primary"  style="font-family:gabrilla;border-radius:10px;">Gallery</h1>
            </div>
            <div class="row">
               <div class="col-sm-5"></div>
               <div class="col-sm-2"><hr style="border:2px solid #0d6efd;margin-top:-5px;margin-left:30px;border-radius:10%;"/></div>
               <div class="col-sm-5"></div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <p class="text-center text-secondary" >Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea. Quia fugiat sit in iste officiis commodi quidem hic quas.</p>
            </div>
        </div>
       </div>
    </div>
    <!----------------All Images----------------->
    <div class="container-fluid">
        
        <div class="row mt-4">
            <div class="col-sm-3 img2">
                <img src="img/gallery/gallery-1.jpg" width="100%">
            </div>
            <div class="col-sm-3 img2">
                <img src="img/gallery/gallery-2.jpg" width="100%">
            </div>
            <div class="col-sm-3 img2">
                <img src="img/gallery/gallery-3.jpg" width="100%">
            </div>
            <div class="col-sm-3 img2">
                <img src="img/gallery/gallery-4.jpg" width="100%">
            </div>
            
        </div>
        <div class="row mt-4">
            <div class="col-sm-3 img2">
                <img src="img/gallery/gallery-5.jpg" width="100%">
            </div>
            <div class="col-sm-3 img2">
                <img src="img/gallery/gallery-6.jpg" width="100%">
            </div>
            <div class="col-sm-3 img2">
                <img src="img/gallery/gallery-7.jpg" width="100%">
            </div>
            <div class="col-sm-3 img2">
                <img src="img/gallery/gallery-8.jpg" width="100%">
            </div>
            
        </div>
        <div class="row mt-5 bg-dark" style="min-height:350px;">
                <div class="col-sm-1"></div>
                    <div class="col-sm-10">
                        <div class="row">
                            <div class="col-sm-3">
                                <h1 class="text-info mt-4"><span class="text-info">||</span> &nbsp;Medilink</h1><br/>
                                <p class="text-white" style="text-align:justify;">We started our journey since 2002 and thus state with pride and gratitude that we have completed two decades of journey successfully. Our team at Medilink Multispecialty Hospitals consists of specialists & Super specialists from all Branches.</p>
                            </div>
                            <div class="col-sm-3 mt-4">
                                <h5 class="text-info mx-4">USEFUL LINKS</h5><hr class="mx-4" style="border:2px solid pink;"/>
                                <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;"> >  Home</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                                <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;"> >  About Us</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                                <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;"> >  Portpolio</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                                <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;"> >  Career</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                                <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;"> >  Contact</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                            </div>
                            <div class="col-sm-3 mt-4">
                                <h5 class="text-info mx-4">Contact Us</h5><hr class="mx-4 " style="border:2px solid pink;"/>
                                <p class="text-white mx-4">Medilink<br/>
                                    Near New Spainees Hotel<br/>
                                    NewYork City , 226006<br/>
                                    U.S.A<br/>
                                    Call us @ + 91 7080102011<br/>
                                    Email @infomedilink.com<br/>
                                </p>
                                <div class="row">
                                    <div class="col-sm-1"></div>
                                    <div class="col-sm-2 rad" style="border-radius:50%;background-color:grey;height:50px;width:50px;"  >
                                       <i class="fa-brands fa-instagram" style="color:red;padding:1px;margin-top:12px;font-size:25px;"></i>
                                    </div>
                                    <div class="col-sm-2 rad" style="border-radius:50%;background-color:grey;height:50px;width:50px;" >
                                        <i class="fa-brands fa-facebook" style="color:blue;padding:1px;margin-top:12px;font-size:25px;"></i>
                                    </div>
                                   <div class="col-sm-2 rad" style="border-radius:50%;background-color:grey;height:50px;width:50px;" >
                                        <i class="fa-brands fa-youtube" style="color:red;margin-top:14px;font-size:23px;"></i>
                                    </div>
                                    <div class="col-sm-2 rad" style="border-radius:50%;background-color:grey;height:50px;width:50px;" >
                                        <i class="fa-brands fa-twitter" style="color:skyblue;padding:1px;margin-top:12px;font-size:25px;"></i>
                                    </div>
                                    <div class="col-sm-2 rad" style="border-radius:50%;background-color:grey;height:50px;width:50px;" >
                                        <i class="fa-brands fa-linkedin" style="color:blue;padding:1px;margin-top:12px;font-size:25px;"></i>
                                    </div>
                                    <div class="col-sm-1"></div>
                                </div>
                            </div>
                            <div class="col-sm-3 mt-4">
                                <h5 class=" mx-4 text-info" style="color:white;">DOWNLOADS</h5><hr class="mx-4" style="border:2px solid pink;"/>
                                <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;"> Hospital PROFILE</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                                <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;font-size:16px;"> Hospital Management</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                                <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;font-size:16px;"> Hospital Facility</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                                <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;font-size:16px;"> Hospital Services</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                        
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-1"></div>
            </div>
            <div class="row bg-dark" style="height:110px;">
            <div class="col-sm-12">
                <p class="text-center mt-4 text-white">© Copyright <strong>Medilink  Hospital.</strong> All Rights Reserved <br/>
                                       Designed by <b style="color:lime;">Mr Shivam Kumar Dixit</b><p>
            </div>
            </div>
    </div>
</body>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js" rel="stylesheet"></script>
<script src="js/app.js"></script>
</html>