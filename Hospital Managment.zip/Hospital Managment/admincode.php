<?php
if(isset($_POST["submit"]))
{
session_start();
$emailaddress=$_POST["emailaddress"];
$password=$_POST["password"];
$con=mysqli_connect('localhost','root','','managementdb');
//$query="INSERT INTO tbl_login (emailaddress, password) VALUES ( '$emailaddress', '$password')";
$query="select password from logcode where emailaddress='$emailaddress'";
$res=mysqli_query($con,$query);
if(mysqli_num_rows($res)>0)
{
    if($row=mysqli_fetch_assoc($res))
    {
        $respassword=$row["password"];
        if($password==$respassword)
        {
            $_SESSION["valid"]=$emailaddress;
            echo "<script>alert('Login Successfully');window.location.href='dashboard.php';</script>";
        }
        else
        {
            echo "<script>alert('Invalid User');window.location.href='medlab.php';</script>";
        }
    }
}
}
else
{
    header("location:medlab.php");
}
?>