<?php
if(isset($_POST["appointment"]))
{
$name=$_POST["name"];
$emailaddress=$_POST["emailaddress"];
$contactno=$_POST["contactno"];
$appointdate=$_POST["appointdate"];
$department=$_POST["department"];
$doctor=$_POST["doctor"];
$address=$_POST["address"];
$con=mysqli_connect("localhost","root","","managementdb");
$query="insert into appoint(name,emailaddress,contactno,appointdate,department,doctor,address) values ('$name','$emailaddress','$contactno','$appointdate','$department','$doctor','$address')";
mysqli_query($con,$query);
echo "<script>alert('Appointment Successfully');window.location.href='medlab.php';</script>";
}
else
{
    
    echo "<script>alert('Registration is not Done');<script>";
}
?>