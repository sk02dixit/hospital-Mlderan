<?php
$name=$_POST["name"];
$gender=$_POST["gender"];
$contactno=$_POST["contactno"];
$address=$_POST["address"];
$dob=$_POST["dob"];
$emailaddress=$_POST["emailaddress"];
$docname=$_POST["docname"];
$appointdate=$_POST["appointdate"];
$con=mysqli_connect("localhost","root","","hospitaldb");
$query="insert into patientdb(name,gender,contactno,address,dob,emailaddress,docname,appointdate) values('$name','$gender','$contactno','$address','$dob','$emailaddress','$docname','$appointdate')";
$query=mysqli_query($con,$query);
echo "<script> alert('Register Successfully');window.location.href='login.php';</script>";
?>