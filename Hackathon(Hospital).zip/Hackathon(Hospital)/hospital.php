<!DOCTYPE html>
<html lang="en">
<head>
    <title>Hospital Management System</title>
    <link href="css/bootstrap.css" rel="stylesheet"/>
       <link href="css/hospital.css" rel="stylesheet"/>
       <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
       <script src="js/bootstrap.bundle.js"></script>

       <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
	
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/solid.min.css" integrity="sha512-uj2QCZdpo8PSbRGL/g5mXek6HM/APd7k/B5Hx/rkVFPNOxAQMXD+t+bG4Zv8OAdUpydZTU3UHmyjjiHv2Ww0PA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        .navbar li:hover
        {
            height:40px;
            background-color:#16a085;
        }
        .navbar li a:hover
        {
            color:red;
        }
    </style>
</head>
<body>
    <!-----------Header------------------->
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12 a1" >
                <div class="row" style="min-height:55px;">
                    <div class="col-sm-1" style="background-color:#16a085;"></div>
                    <div class="col-sm-2" style="background-color:#16a085;">
                        <i class="fa-solid fa-phone mt-3 text-white" ></i><strong class="text-white">&nbsp;&nbsp;Call : 123 456 7895</strong>
                    </div>
                    <div class="col-sm-2" style="background-color:#16a085;">
                        <i class="fa-solid fa-envelope mt-3 text-white"></i><strong class="text-white">&nbsp;&nbsp;info@midilinkhospital</strong>
                    </div>
                    <div class="col-sm-3" style="background-color:#16a085;">
                    <i class="fa-solid fa-location-dot mt-3 text-white"></i><strong class="text-white">&nbsp;&nbsp;Medlink (Ltd) , Newyork City</strong>
                    </div>
                    <div class="col-sm-1" style="background-color:#16a085;"></div>
                    <div class="col-sm-3" style="background-color:#16a085;">
                    <form class="d-flex mt-2" role="search">
                       <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                        <button class="btn btn-outline-info bg-secondary text-white" type="submit">Search</button>
                    </form>
                </div>
            </div>
            <!-----------Header Close------------------->
            <!-------------Header 2----------------->
            <div class="row sticky-top">
                <div class="col-sm-12 bg-white a2" style="min-height:120px;">
                     <div class="row ">
                        <div class="col-sm-1"></div>
                        <div class="col-sm-2 mt-2">
                            <img src="images/logo.png" class="mt-2"width="80%"/>
                        </div>
                        <div class="col-sm-1"></div>
                        <div class="col-sm-7 mt-4">
                        <nav class="navbar navbar-expand-lg bg-body-tertiary">
                            <div class="container-fluid">
                         
                                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                                <b><span class="navbar-toggler-icon"></span>
                                </button>
                                <div class="collapse navbar-collapse" id="navbarNav">
                                    <ul class="navbar-nav">
                                        <li class="nav-item mx-2">
                                           <a class="nav-link" href="hospital.php">Home</a>
                                        </li>
                                        <li class="nav-item mx-4">
                                            <a class="nav-link" href="about.php">About Us</a>
                                        </li>
                                        <li class="nav-item mx-3">
                                            <a class="nav-link" href="enquiery.php">Registration Form</a>
                                        </li>
                                        <li class="nav-item mx-3">
                                            <a class="nav-link" href="login.php">Login</a>
                                        </li>
                                        
                                        <li class="nav-item mx-3">
                                            <a class="nav-link" href="contact.php">Contact Us</a>
                                        </li>
                                        
       
                                    </ul>
                                 </div>
                            </div>
                        </nav></b>
                        </div>
                        <div class="col-sm-1"></div>
                        
                     </div>
                </div>
            </div> 
            <!--------------------Header 2 end------------------>
            <!-------------------Slider Start ------------------>
            <div class="row mt-3">
                <div class="col-sm-9 bg-white p-0">
                    <div id="carouselExampleCaptions" class="carousel slide">
                        
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <img src="images/a3.jpg" class="d-block w-100" height="500px">
                                <div class="carousel-caption d-none d-md-block">
                                    <h1 class="text-info">We Take Care of Healthy Health</h1>
                                    <p class="mb-5" style="font-size:20px">We are Fully Time Available On Your Health</p>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <img src="images/a1.jpg" class="d-block w-100" height="500px" alt="...">
                                <div class="carousel-caption d-none d-md-block">
                                <h1 class="text-info">We Take Care of Healthy Health</h1>
                                    <p class="mb-5" style="font-size:20px">We are Fully Time Available On Your Health</p>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <img src="images/a2.jpg" class="d-block w-100" height="500px" alt="...">
                                <div class="carousel-caption d-none d-md-block">
                                <h1 class="text-info">We Take Care of Healthy Health</h1>
                                    <p class="mb-5" style="font-size:20px">We are Fully Time Available On Your Health</p>
                                </div>
                            </div>
                        </div>
                        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Previous</span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Next</span>
                        </button>
                    </div>
                </div>
                <div class="col-sm-3" style="border:5px solid #16a085;background-color:white;">
                <div class="row">
                  <div class="col-sm-12" style="height:40px;background-color:#16a085;"><p style="color:white;margin-left:120px;font-size:20px;font-family:gabrilla;">Notice Board</p></div>
                  <div class="col-sm-12" style="height:425px;">
                  <marquee direction="up" height="450px;" onmouseout="start()" onmouseover="stop()">
                    <p><img src="images/new.gif" width="12%" height="7%" /><span style="color:#16a085;">Eye examination(fondues check up).</span></p>
                    <p><img src="images/new.gif" width="12%" height="7%"/><span style="color:#16a085;">Dental examination – Every 6 months</span></p>
                    <p><img src="images/new.gif" width="12%" height="7%"/><span style="color:#16a085;">Heart examination (ECG) – yearly</span></p>
                    <p><img src="images/new.gif" width="12%" height="7%"/><span style="color:#16a085;">Liver examination (fatty liver test).</span></p>
                    <p><img src="images/new.gif" width="12%" height="7%"/><span style="color:#16a085;">Kidney examination (S.creatinine) </span></p>
                    <p><img src="images/new.gif" width="12%" height="7%"/><span style="color:#16a085;">Foot examination (neuropathy)</span></p>
                    <p><img src="images/new.gif" width="12%" height="7%"/><span style="color:#16a085;">Dental surgeon</span></p>
                    <p><img src="images/new.gif" width="12%" height="7%"/><span style="color:#16a085;">Dental examination – Every 6 months</span></p>
                    <p><img src="images/new.gif" width="12%" height="7%"/><span style="color:#16a085;">Heart examination (ECG) – yearly</span></p>
                    
                    
                  </marquee>
                  </div>
                </div>
              </div>
            </div>
            <!-----------------Images---------------->
            <div class="row bg-white">
                <div class="col-sm-6">
                    <img src="images/home-img.svg"/>
                </div>
                <div class="col-sm-6 mt-5">
                    <h1 class="mx-5 mt-5" style="font-size:45px;font-family:gabrilla;"><span class="text-info">Medilink </span>Hospitals</h1>
                    <h4  class="mx-5" style="font-family:carsiva;color:pink; ">Multispeciality Hospitals</h4>
                    <p class="mx-5" style="text-align:justify;color:grey;">We started our journey since 2002 and thus state with pride and gratitude that we have completed two decades of journey successfully. Our team at Medilink Multispecialty Hospitals consists of specialists & Super specialists from all Branches. We are serving from two branches in Ahmedabad- Satellite & Sabarmati. Both the units are state-of-art multi-speciality hospital set ups situated at strategic locations, and have all required departments/facilities. Apart from this, we also have 24 *7 Radiology, pathology & In-house Pharmacy services.</p><br/>
                    <p class="mx-5"style="text-align:justify;color:grey;">One of our major speciality, is being run under the banner of Medilink Diabetes Clinics, and headed by the Diabetic & Metabolic Physician and Diabetologist Dr. Manish Agarwal. We, at Medilink Diabetes Clinic are dedicated to delivering world-class care and management of diabetes and related metabolic disorders.</p>
                </div>
                
            </div>
            <!------------------Images 1 end--------------->
            <!------------------Images 2 External--------------->
            <div class="row" style="background-color:#ffffff;">
                <div class="col-sm-6">
                <h1 class="mx-5" style="font-family:carsiva;"><span class="text-info">OUR</span> SERVICES</h1>
                <p class="mx-5 mt-3" style="text-align:justify;color:grey;">Hospitals have long existed in most countries. Developing countries, which contain a large proportion of the world’s population, generally do not have enough hospitals, equipment, and trained staff to handle the volume of persons who need care. Thus, people in these countries do not always receive the benefits of modern medicine, public health measures, or hospital care, and they generally have lower life expectancies.</p><br/>
                <p class="mx-5 mt-3" style="text-align:justify;color:grey;">It can be said, however, that the modern concept of a hospital dates from 331 CE when Roman emperor Constantine I (Constantine the Great), having been converted to Christianity, abolished all pagan hospitals and thus created the opportunity for a new start.Until that time disease had isolated the sufferer from the community. Illness thus became a  and thus created the opportunity for a matter for the Christian church.</p>
                </div>
                <div class="col-sm-6" >
                    <img src="images/a9.gif" width="100%"/>
                </div>
                
            </div>
            <!------------------Images 2 External end--------------->
            <!------------------our service------------------------>
            <div class="row bg-white mt-1" style="background-image:url('images/footer-bg.png');height:180px;background-repeat:no-repeat;">
                <div class="col-sm-4"></div>
                <div class="col-sm-5">
                    <h2 class="mx-5 ms-5 mt-5"><span class="text-info" style="height:50px;border-bottom:4px solid pink;border-radius:10px;">CASHLESS</span> TREATMENT</h2>
                    <p style="color:pink;">we accept most leading health insurance policies. Avail the benefits of</p>
                </div>
                <div class="col-sm-3"></div>
            </div>
            <!---------------------Our Service End ---------------------->
            <!--------------------ALL Image --------------------->
            <div class="row">
                <div class="col-sm-1"></div>
                <div class="col-sm-10">
                    <div class="row">
                        <div class="col-sm-3">
                        <div class="card" style="width:100%;">
                           <img src="images/4.png" class="card-img-top" alt="...">
                               
                            </div>
                        </div>
                        <div class="col-sm-3">
                        <div class="card" style="width:100%;">
                           <img src="images/6.png" class="card-img-top" alt="...">
                               
                            </div>
                        </div>
                        <div class="col-sm-3">
                        <div class="card" style="width:100%;">
                           <img src="images/14.png" class="card-img-top" alt="...">
                               
                            </div>
                        </div>
                        <div class="col-sm-3">
                        <div class="card" style="width:100%;">
                           <img src="images/19.png" class="card-img-top" alt="...">
                               
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-1"></div>
            </div>
            
            <div class="row mt-5">
                <div class="col-sm-1"></div>
                <div class="col-sm-10">
                    <div class="row">
                        <div class="col-sm-3">
                        <div class="card" style="width:100%;">
                           <img src="images/7.png" class="card-img-top" alt="...">
                               
                            </div>
                        </div>
                        <div class="col-sm-3">
                        <div class="card" style="width:100%;">
                           <img src="images/8.png" class="card-img-top" alt="...">
                               
                            </div>
                        </div>
                        <div class="col-sm-3">
                        <div class="card" style="width:100%;">
                           <img src="images/15.png" class="card-img-top" alt="...">
                               
                            </div>
                        </div>
                        <div class="col-sm-3">
                        <div class="card" style="width:100%;">
                           <img src="images/9.png" class="card-img-top" alt="...">
                               
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-1"></div>
            </div>
            <!------------------All images End ------------------------>
            <!----------------------Footer-------------------------------->
            <div class="row mt-5" style="min-height:350px;background-color:#16a085;">
                <div class="col-sm-1"></div>
                    <div class="col-sm-10">
                        <div class="row">
                            <div class="col-sm-3">
                                <h1 class="text-info mt-4"><span class="text-info">||</span> &nbsp;Medilink</h1><br/>
                                <p class="text-white" style="text-align:justify;">We started our journey since 2002 and thus state with pride and gratitude that we have completed two decades of journey successfully. Our team at Medilink Multispecialty Hospitals consists of specialists & Super specialists from all Branches.</p>
                            </div>
                            <div class="col-sm-3 mt-4">
                                <h5 class="text-info mx-4">USEFUL LINKS</h5><hr class="mx-4" style="border:2px solid pink;"/>
                                <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;"> >  Home</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                                <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;"> >  About Us</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                                <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;"> >  Portpolio</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                                <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;"> >  Career</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                                <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;"> >  Contact</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                            </div>
                            <div class="col-sm-3 mt-4">
                                <h5 class="text-info mx-4">Contact Us</h5><hr class="mx-4 " style="border:2px solid pink;"/>
                                <p class="text-white mx-4">Medilink<br/>
                                    Near New Spainees Hotel<br/>
                                    NewYork City , 226006<br/>
                                    U.S.A<br/>
                                    Call us @ + 91 7080102011<br/>
                                    Email @infomedilink.com<br/>
                                </p>
                                <div class="row">
                                    <div class="col-sm-1"></div>
                                    <div class="col-sm-2 rad" style="border-radius:50%;background-color:grey;height:50px;width:50px;"  >
                                       <i class="fa-brands fa-instagram" style="color:red;padding:1px;margin-top:12px;font-size:25px;"></i>
                                    </div>
                                    <div class="col-sm-2 rad" style="border-radius:50%;background-color:grey;height:50px;width:50px;" >
                                        <i class="fa-brands fa-facebook" style="color:blue;padding:1px;margin-top:12px;font-size:25px;"></i>
                                    </div>
                                   <div class="col-sm-2 rad" style="border-radius:50%;background-color:grey;height:50px;width:50px;" >
                                        <i class="fa-brands fa-youtube" style="color:red;margin-top:14px;font-size:23px;"></i>
                                    </div>
                                    <div class="col-sm-2 rad" style="border-radius:50%;background-color:grey;height:50px;width:50px;" >
                                        <i class="fa-brands fa-twitter" style="color:skyblue;padding:1px;margin-top:12px;font-size:25px;"></i>
                                    </div>
                                    <div class="col-sm-2 rad" style="border-radius:50%;background-color:grey;height:50px;width:50px;" >
                                        <i class="fa-brands fa-linkedin" style="color:blue;padding:1px;margin-top:12px;font-size:25px;"></i>
                                    </div>
                                    <div class="col-sm-1"></div>
                                </div>
                            </div>
                            <div class="col-sm-3 mt-4">
                                <h5 class=" mx-4 text-info" style="color:white;">DOWNLOADS</h5><hr class="mx-4" style="border:2px solid pink;"/>
                                <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;"> Hospital PROFILE</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                                <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;font-size:16px;"> Hospital Management</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                                <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;font-size:16px;"> Hospital Facility</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                                <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;font-size:16px;"> Hospital Services</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                        
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-1"></div>
            </div>
            <!----------------------Footer End -------------------------------->
            <div class="row" style="height:110px;background-color:#16a085;">
            <div class="col-sm-12">
                <p class="text-center mt-4 text-white">© Copyright <strong>Medilink  Hospital.</strong> All Rights Reserved <br/>
                                       Designed by <span style="color:red;">Mr Shivam Kumar Dixit</span><p>
            </div>
            </div>
        </div>
        </div>   
    </div>
</body>
</html>