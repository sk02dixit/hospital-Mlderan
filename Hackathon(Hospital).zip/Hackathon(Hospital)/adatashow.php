<!DOCTYPE html>
<html lang="en">
<head>
    <title>Hospital Management System</title>
    <link href="css/bootstrap.css" rel="stylesheet"/>
       <link href="css/hospital.css" rel="stylesheet"/>
       <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
       <script src="js/bootstrap.bundle.js"></script>

       <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
	
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/solid.min.css" integrity="sha512-uj2QCZdpo8PSbRGL/g5mXek6HM/APd7k/B5Hx/rkVFPNOxAQMXD+t+bG4Zv8OAdUpydZTU3UHmyjjiHv2Ww0PA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        .navbar li:hover
        {
            height:40px;
            background-color:#16a085;
        }
        .navbar li a:hover
        {
            color:red;
        }
    </style>
</head>
<body>
    <!-----------Header------------------->
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12 a1" >
                <div class="row" style="min-height:55px;">
                    <div class="col-sm-1" style="background-color:#16a085;"></div>
                    <div class="col-sm-2" style="background-color:#16a085;">
                        <i class="fa-solid fa-phone mt-3 text-white" ></i><strong class="text-white">&nbsp;&nbsp;Call : 123 456 7895</strong>
                    </div>
                    <div class="col-sm-2" style="background-color:#16a085;">
                        <i class="fa-solid fa-envelope mt-3 text-white"></i><strong class="text-white">&nbsp;&nbsp;info@midlinkhospital</strong>
                    </div>
                    <div class="col-sm-3" style="background-color:#16a085;">
                    <i class="fa-solid fa-location-dot mt-3 text-white"></i><strong class="text-white">&nbsp;&nbsp;Medlink (Ltd) , Newyork City</strong>
                    </div>
                    <div class="col-sm-1" style="background-color:#16a085;"></div>
                    <div class="col-sm-3" style="background-color:#16a085;">
                    <form class="d-flex mt-2" role="search">
                       <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                        <button class="btn btn-outline-info bg-secondary text-white" type="submit">Search</button>
                    </form>
                </div>
            </div>
            <!-----------Header Close------------------->
            <!-------------Header 2----------------->
            <div class="row">
                <div class="col-sm-12 bg-white a2" style="min-height:120px;border-bottom:2px dashed #16a085">
                     <div class="row ">
                        <div class="col-sm-1"></div>
                        <div class="col-sm-2 mt-2">
                            <img src="images/logo.png" class="mt-2"width="80%"/>
                        </div>
                        <div class="col-sm-1"></div>
                        <div class="col-sm-7 mt-4">
                        <nav class="navbar navbar-expand-lg bg-body-tertiary">
                            <div class="container-fluid">
                         
                                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                                <b><span class="navbar-toggler-icon"></span>
                                </button>
                                <div class="collapse navbar-collapse" id="navbarNav">
                                    <ul class="navbar-nav">
                                        <li class="nav-item mx-2">
                                           <a class="nav-link" href="hospital.php">Home</a>
                                        </li>
                                        <li class="nav-item mx-4">
                                            <a class="nav-link" href="about.php">About Us</a>
                                        </li>
                                        <li class="nav-item mx-3">
                                            <a class="nav-link" href="appointment.php">Appointment Form</a>
                                        </li>
                                        <li class="nav-item mx-3">
                                            <a class="nav-link" href="login.php">Login</a>
                                        </li>
                                        <li class="nav-item mx-3">
                                            <a class="nav-link" href="enquiery.php">Enquiery </a>
                                        </li>
                                        <li class="nav-item mx-3">
                                            <a class="nav-link" href="contact.php">Contact Us</a>
                                        </li>
                                        
       
                                    </ul>
                                 </div>
                            </div>
                        </nav></b>
                        </div>
                        <div class="col-sm-1"></div>
                        
                     </div>
                </div>
            </div> 
            <!--------------------Header 2 end------------------>
                  <div class="row">
                    <table border="1" class="bg-info">
                        <tr>
                        <th>SR.NO</th>
                        <th>Mobile NO</th>
                        <th>Email</th>
                        <th>Name</th>
                        <th>Dob</th>
                        <th>Guardian Mobile</th>
                        <th>Problem</th>
                        <th>Gender</th>
                        <th>Appointdate Date</th>
                        <th>Pincode</th>
                        <th>Address</th>
                        </tr>
                        <tbody>
                <?php
                $con=mysqli_connect("localhost","root","","hospitaldb");
                $query="select * from hospital_patient";
                $res=mysqli_query($con,$query);
                $i=1;
                while($row=mysqli_fetch_assoc($res)){
                ?>
                   <tr>
                        <td><?php echo $i; ?><input type="hidden" name="id" value="<?php echo $row["id"];?>"/></td>
                        <td><?php echo $row["contactno"];?></td>
                        <td><?php echo $row["emailaddress"];?></td>
                        <td><?php echo $row["name"];?></td>
                        <td><?php echo $row["dob"];?></td>
                        <td><?php echo $row["guardianmo"];?></td>
                        <td><?php echo $row["problem"];?></td>
                        <td><?php echo $row["gender"];?></td>
                        <td><?php echo $row["adate"];?></td>
                        <td><?php echo $row["pincode"];?></td>
                        <td><?php echo $row["address"];?></td>
                       
                   </tr>
                <?php
                $i++;
                }
                ?>
            </tbody>
                    </table>
                  </div>
            <!------------------All images End ------------------------>
            <!----------------------Footer-------------------------------->
            <div class="row" style="min-height:350px;background-color:#16a085;">
                <div class="col-sm-1"></div>
                    <div class="col-sm-10">
                        <div class="row">
                            <div class="col-sm-3">
                                <h1 class="text-info mt-4"><span class="text-info">||</span> &nbsp;Medilink</h1><br/>
                                <p class="text-white" style="text-align:justify;">We started our journey since 2002 and thus state with pride and gratitude that we have completed two decades of journey successfully. Our team at Medilink Multispecialty Hospitals consists of specialists & Super specialists from all Branches.</p>
                            </div>
                            <div class="col-sm-3 mt-4">
                                <h5 class="text-info mx-4">USEFUL LINKS</h5><hr class="mx-4" style="border:2px solid pink;"/>
                                <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;"> >  Home</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                                <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;"> >  About Us</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                                <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;"> >  Portpolio</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                                <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;"> >  Career</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                                <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;"> >  Contact</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                            </div>
                            <div class="col-sm-3 mt-4">
                                <h5 class="text-info mx-4">Contact Us</h5><hr class="mx-4 " style="border:2px solid pink;"/>
                                <p class="text-white mx-4">Medilink<br/>
                                    Near New Spainees Hotel<br/>
                                    NewYork City , 226006<br/>
                                    U.S.A<br/>
                                    Call us @ + 91 7080102011<br/>
                                    Email @infomedilink.com<br/>
                                </p>
                                <div class="row">
                                    <div class="col-sm-1"></div>
                                    <div class="col-sm-2 rad" style="border-radius:50%;background-color:grey;height:50px;width:50px;"  >
                                       <i class="fa-brands fa-instagram" style="color:red;padding:1px;margin-top:12px;font-size:25px;"></i>
                                    </div>
                                    <div class="col-sm-2 rad" style="border-radius:50%;background-color:grey;height:50px;width:50px;" >
                                        <i class="fa-brands fa-facebook" style="color:blue;padding:1px;margin-top:12px;font-size:25px;"></i>
                                    </div>
                                   <div class="col-sm-2 rad" style="border-radius:50%;background-color:grey;height:50px;width:50px;" >
                                        <i class="fa-brands fa-youtube" style="color:red;margin-top:14px;font-size:23px;"></i>
                                    </div>
                                    <div class="col-sm-2 rad" style="border-radius:50%;background-color:grey;height:50px;width:50px;" >
                                        <i class="fa-brands fa-twitter" style="color:skyblue;padding:1px;margin-top:12px;font-size:25px;"></i>
                                    </div>
                                    <div class="col-sm-2 rad" style="border-radius:50%;background-color:grey;height:50px;width:50px;" >
                                        <i class="fa-brands fa-linkedin" style="color:blue;padding:1px;margin-top:12px;font-size:25px;"></i>
                                    </div>
                                    <div class="col-sm-1"></div>
                                </div>
                            </div>
                            <div class="col-sm-3 mt-4">
                                <h5 class=" mx-4 text-info" style="color:white;">DOWNLOADS</h5><hr class="mx-4" style="border:2px solid pink;"/>
                                <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;"> Hospital PROFILE</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                                <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;font-size:16px;"> Hospital Management</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                                <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;font-size:16px;"> Hospital Facility</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                                <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;font-size:16px;"> Hospital Services</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                        
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-1"></div>
            </div>
            <!----------------------Footer End -------------------------------->
            <div class="row" style="height:110px;background-color:#16a085;">
            <div class="col-sm-12">
                <p class="text-center mt-4 text-white">© Copyright <strong>Medilink  Hospital.</strong> All Rights Reserved <br/>
                                       Designed by <span style="color:red;">Mr Shivam Kumar Dixit</span><p>
            </div>
            </div>
        </div>
        </div>   
    </div>
</body>
</html>