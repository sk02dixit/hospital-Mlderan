<?php
$contactno=$_POST["contactno"];
$emailaddress=$_POST["emailaddress"];
$name=$_POST["name"];
$dob=$_POST["dob"];
$guardianmo=$_POST["guardianmo"];
$problem=$_POST["problem"];
$gender=$_POST["gender"];
$adate=$_POST["adate"];
$pincode=$_POST["pincode"];
$address=$_POST["address"];
$date=date('d/m/y');
$con=mysqli_connect("localhost","root","","hospitaldb");
$query="insert into hospital_patient(contactno,emailaddress,name,dob,guardianmo,problem,gender,adate,pincode,address,date) values('$contactno','$emailaddress','$name','$dob','$guardianmo','$problem','$gender','$adate','$pincode','$address','$date')";
mysqli_query($con,$query);
echo "<script>alert('Registration Successfully');window.location.href='login.php';</script>";
?>