

<?php
session_start();
$emailaddress=$_POST["emailaddress"];
$password=$_POST["password"];
$con=mysqli_connect('localhost','root','','hospitaldb');
//$query="INSERT INTO tbl_login (emailaddress, password) VALUES ( '$emailaddress', '$password')";
$query="select * from hospital_form";
$res=mysqli_query($con,$query);
$row=mysqli_fetch_assoc($res);
if($row['emailaddress']==$emailaddress && $row['password']==$password)
{
    $_SESSION['user']=$emailaddress;    
    header("Location:view.php");

}else
{
    echo "location:login.php?msg=1";
}
?>